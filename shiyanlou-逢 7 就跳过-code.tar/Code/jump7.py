for n in range(1,101):
    if n%10 == 7:
        continue
    elif n % 7==0:
        continue
    elif n // 10 ==7:
        continue
    else:
        print(n)
